from langchain.document_loaders.unstructured import UnstructuredFileLoader
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain.vectorstores import Chroma, Pinecone
from langchain.embeddings.openai import OpenAIEmbeddings
from langchain.chains.question_answering import load_qa_chain
import pinecone
from langchain.llms import OpenAI
import os

os.environ["OPENAI_API_KEY"] = '#########'
OPENAI_API_KEY = '#########'
PINECONE_API_KEY ='#########'
PINECONE_API_ENV = '#########'


def processquery(inputData):
    splittedstring = inputData.split(",")
    document = splittedstring[0]
    question = splittedstring[1]
    loader = UnstructuredFileLoader(document)
    data = loader.load()
    text_splitter = RecursiveCharacterTextSplitter(chunk_size=1000, chunk_overlap=0)
    texts = text_splitter.split_documents(data)
    embeddings = OpenAIEmbeddings(openai_api_key=OPENAI_API_KEY)
    pinecone.init(
        api_key=PINECONE_API_KEY,
        environment=PINECONE_API_ENV
    )
    index_name = "langchainindex1"
    docsearch = Pinecone.from_texts([t.page_content for t in texts], embeddings, index_name=index_name)
    query = question
    llm = OpenAI(temperature=0, openai_api_key=OPENAI_API_KEY)
    chain = load_qa_chain(llm, chain_type="stuff")
    docs = docsearch.similarity_search(query, include_metadata=True)
    return chain.run(input_documents=docs, question=query)
